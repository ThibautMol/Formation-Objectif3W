<?php

// if (((isset($_SESSION['SPARE']['FIRST_VISIT'])) && ($_SESSION['SPARE']['FIRST_VISIT']==0)) || (!isset($_SESSION['SPARE']['FIRST_VISIT'])) || (empty($_SESSION['SPARE']['FIRST_VISIT']))) {

//     unset($_SESSION);

//     header('Location: http://localhost/Formation-Objectif3W/Projet-spare/code/login.php');
//     exit;

// }

?>