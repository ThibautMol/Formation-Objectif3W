<footer class="bg-dark text-center text-white fixed-bottom">
            <!-- Copyright -->
            <div class="text-center p-3">
                © 2023 Copyright:
                <a class="text-white" target="_blank" href="https://objectif3w.com/">Objectif 3W</a>
            </div>
            <!-- Copyright -->
        </footer>
        <!-- Footer -->
    </body>
</html>