<?php

// function mdp_generator ($firstname, $lastname) {
//         $UserPwd=substr($firstname, 0 , 1).$lastname; 
//         return $UserPwd;
//     }

//     $UserPwd=mdp_generator($firstname,$lastname);


// ?>