<?php

function enable() {
    return $is_disabled=NULL;
}

$is_disabled=enable();

?>