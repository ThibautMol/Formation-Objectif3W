<?php 

require_once (".\assets\inc\mysql-profil-user-request.php");

$all_profil_user;

?>