<?php

function disable(){
    return  $is_disabled=1;
}

$is_disabled=disable();


?>