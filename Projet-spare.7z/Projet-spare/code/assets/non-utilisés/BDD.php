<?php
    $user1 = [
            'email'=>'bob@mail.com',
            'password'=>'bob'
    ];

    $user2 = [
        'email'=>'sophie@mail.com',
        'password'=>'sophie'
    ];

    $user3 = [
        'email'=>'jean@mail.com',
        'password'=>'jean'
    ];

    $bdd = [
        $user1, $user2, $user3
    ];
